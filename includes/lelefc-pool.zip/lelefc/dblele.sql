-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2021 at 05:46 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dblele`
--

-- --------------------------------------------------------

--
-- Table structure for table `bobot`
--

CREATE TABLE IF NOT EXISTS `bobot` (
`id_bobot` int(4) NOT NULL,
  `kd_gejala` varchar(4) NOT NULL,
  `kd_penyakit` varchar(4) NOT NULL,
  `bobot` int(1) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `bobot`
--

INSERT INTO `bobot` (`id_bobot`, `kd_gejala`, `kd_penyakit`, `bobot`) VALUES
(1, 'g01', 'p1', 5),
(2, 'g02', 'p1', 3),
(3, 'g03', 'p1', 3),
(4, 'g04', 'p2', 3),
(5, 'g05', 'p2', 5),
(6, 'g06', 'p2', 3),
(7, 'g07', 'p3', 5),
(8, 'g08', 'p3', 3),
(9, 'g09', 'p3', 3),
(10, 'g10', 'p3', 3),
(12, 'g11', 'p4', 5),
(13, 'g12', 'p4', 3),
(14, 'g13', 'p4', 5),
(15, 'g14', 'p4', 3);

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE IF NOT EXISTS `gejala` (
  `kd_gejala` varchar(4) NOT NULL,
  `gejala` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`kd_gejala`, `gejala`) VALUES
('g14', 'Bagian sirip dan perut pendarahan'),
('g13', 'Sering muncul vertikal tegak di permukaan'),
('g11', 'Ikan terinfeksi terlihat lemah'),
('g12', 'Berenang berputar-putar'),
('g10', 'Jamur ini juga sering menyerang telur dengan menyelimuti telur dengan benang seperti kapas.'),
('g09', 'Jamur ini juga suka menyerang telur dengan menyelimuti telur dengan benang seperti kapas.'),
('g08', 'Ikan sudah lemah seperti daerah kepala tutup insang, sirip, serta tubuh lainnya.'),
('g07', 'Tubuh ikan ditumbuhi sekumpulan benang halus seperti kapas yang dapat ditemukan didaerah luka.'),
('g05', 'Terdapat bintik-bintik berwarna putih pada kulit, sirip, dan insang.'),
('g06', 'Ikan memperlihatkan perlaku menggosok-gosokkan tubuh pada dasar atau dinding kolam.'),
('g04', 'Ikan terlihat sangat lemah dan selalu timbul di permukaan air.'),
('g03', 'Kesulitan bernapas, terlihat megap-megap dipermukaan air.'),
('g02', 'Kulit kesat dan timbul pendarahan'),
('g01', 'Warna tubuh menadi gelap');

-- --------------------------------------------------------

--
-- Table structure for table `hasil`
--

CREATE TABLE IF NOT EXISTS `hasil` (
`id_hasil` int(4) NOT NULL,
  `id_peternak` int(4) NOT NULL,
  `kd_penyakit` varchar(4) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `hasil`
--

INSERT INTO `hasil` (`id_hasil`, `id_peternak`, `kd_penyakit`, `tanggal`) VALUES
(40, 26, 'p2', '2021-05-11'),
(39, 26, 'p2', '2021-05-11'),
(3, 17, 'p3', '2021-05-23'),
(4, 17, 'p3', '2021-04-23'),
(5, 18, 'p3', '2021-04-24'),
(6, 18, 'p3', '2021-04-24'),
(7, 21, 'p3', '2021-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3'),
('herlina', '4e196a6c133a04f8a81d742b04e7ffe7');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE IF NOT EXISTS `penyakit` (
  `kd_penyakit` varchar(4) NOT NULL,
  `nama_penyakit` varchar(100) DEFAULT NULL,
  `definisi` text,
  `solusi` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`kd_penyakit`, `nama_penyakit`, `definisi`, `solusi`) VALUES
('p1', 'Aeromonas hydrophila dan Pseudomonas hydrophyla', 'Ini berkembang sebagai akibat serangan dari bakteri dari genus Aeromonas hydrophila dan Pseudomonas hydrophila. Serangan hydrophila Aeromonas. Penyakit lele yang disebabkan oleh bakteri ini menyebabkan perut ikan menggembung cairan getah bening, pembengkakan, ikan luka fisik sirip dan luas. Faktor lele memicu penyakit ini adalah penumpukan pakan sisa membusuk di dasar kolam.', 'Untuk mencegah hal ini, pertahankan suhu air 28oC. Pengobatan yang paling umum dalam benih ikan adalah oxytetracycline antibiotik. Caranya dengan mencampur OTC dengan pakan, dosis 50 mg per kg pakan. Berikan selama 7-10 hari. Jika penyakit ini menyerang kolam pemeliharaan lele, perubahan air tambak dua kali sehari. Pada saat penggantian air, tambahkan garam dengan dosis 100-200 gram /M3.'),
('p2', 'Gatal Trichodiniasis', 'Trichodiniasis penyakit gatal-gatal yang disebabkan oleh jenis protozoa Trichodina. Gejala lele Trichodiniasis adalah ikan terlihat lemas, warna tubuh kusam dan sering menggosok-gosokkan tubuhnya ke dinding dan dasar kolam. Penyakit ini ditularkan lele karena kontak langsung dan juga melalui perantara air.\r\nParasit dari golongan ciliata berbentuk bulat, terkadang amuboid, serta mempunyai inti beerbentuk tapal kuda yang disebut Ichthyophthirius multifilis juga dapat memicu timbulnya penyakit ini.Kepadatan ikan yang terlalu tinggi dan kekurangan oksigen disinyalir memicu perkembangannya.', 'Penyakit ikan lele ini bisa dicegah dengan mengatur kepadatan tebar dan menjaga kualitas air.\r\nPengobatan\r\n\r\nRendam ikan pada campuran larutan Formalin 25 cc/m³ dan larutan Malachyte Green Oxalate 0,1 g/m³ selama 12-24 jam.\r\n\r\nGanti kolam dengan air segar.\r\n\r\nUlangi langkah pengobatan setelah 3 hari.'),
('p3', 'Parasit / Jamur saprolegnia', 'Penyakit ini disebabkan serangan  jamur saprolegnia yang tumbuh sebagai saprofit pada jaringan tubuh yang mati atau iakn yang kondisinya lemah.', 'Pengobataan\r\n\r\nRendam benih gelondongan dan iakn dewasa dalam larutan Malachyte Green oxalate denagn dosis 2,5-3 ppm selam 30 menit.\r\n\r\nRendam telur dalam larutan Malachyte Green oxalate denagn dosis 0,1-0,2 ppm selama 1 jam atau 5-10 ppm selama 15 menit.'),
('p4', 'Serangan Channel catfish virus', 'Virus herpes ini adalah penyakit yang menyerang ikan terinfeksi terlihat lemah, berenang berputar-putar, sering muncul vertikal tegak di permukaan, bagian sirip dan perut pendarahan. Faktor pemicu penyakit lele fluktuasi suhu air, degradasi kualitas air dan padat penebaran tinggi.', 'Pengendalian Penyakit\r\nUntuk mencegah serangan virus ini adalah dengan cara memperbaiki manajemen budidaya, menjaga kebersihan kolam dan pemberian pakan yang berkualitas.\r\nPengobatan\r\n\r\nLakukan Pergantian air seminggu 1 kali.\r\n\r\nAir Di ganti cukup 50 % saja.\r\n\r\nBeri kolam daun pepaya dan mengkudu.\r\n\r\nGanti daun pepaya dan mengkudu tersebut 2 hari 1 kali.');

-- --------------------------------------------------------

--
-- Table structure for table `peternak`
--

CREATE TABLE IF NOT EXISTS `peternak` (
`id_peternak` int(4) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kelamin` char(10) NOT NULL,
  `umur` varchar(3) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `noip` varchar(30) NOT NULL,
  `tanggal` datetime NOT NULL,
  `jns_peternakan` char(20) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `peternak`
--

INSERT INTO `peternak` (`id_peternak`, `nama`, `kelamin`, `umur`, `alamat`, `noip`, `tanggal`, `jns_peternakan`, `email`) VALUES
(8, 'cut lia', 'Laki-laki', '2', 'Subah', '127.0.0.1', '2013-08-15 11:11:53', 'Intensif', 'cutliati@gmail.com'),
(9, 'Munzil', 'Laki-laki', '65', 'Banyuputih', '127.0.0.1', '2013-09-16 04:16:18', 'Intensif', 'munzill12@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tmp_analisa`
--

CREATE TABLE IF NOT EXISTS `tmp_analisa` (
  `noip` varchar(30) NOT NULL,
  `kd_penyakit` char(4) NOT NULL,
  `kd_gejala` char(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_gejala`
--

CREATE TABLE IF NOT EXISTS `tmp_gejala` (
`noip` int(3) NOT NULL,
  `kd_gejala` char(4) NOT NULL,
  `bobot` int(1) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=131388 ;

--
-- Dumping data for table `tmp_gejala`
--

INSERT INTO `tmp_gejala` (`noip`, `kd_gejala`, `bobot`) VALUES
(131382, 'g14', 0),
(131383, 'g13', 0),
(131384, 'g09', 0),
(131385, 'g08', 0),
(131386, 'g06', 0),
(131387, 'g04', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tmp_penyakit`
--

CREATE TABLE IF NOT EXISTS `tmp_penyakit` (
  `noip` varchar(30) NOT NULL,
  `kd_penyakit` char(4) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bobot`
--
ALTER TABLE `bobot`
 ADD PRIMARY KEY (`id_bobot`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
 ADD PRIMARY KEY (`kd_gejala`);

--
-- Indexes for table `hasil`
--
ALTER TABLE `hasil`
 ADD PRIMARY KEY (`id_hasil`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
 ADD PRIMARY KEY (`kd_penyakit`);

--
-- Indexes for table `peternak`
--
ALTER TABLE `peternak`
 ADD PRIMARY KEY (`id_peternak`);

--
-- Indexes for table `tmp_analisa`
--
ALTER TABLE `tmp_analisa`
 ADD PRIMARY KEY (`noip`);

--
-- Indexes for table `tmp_gejala`
--
ALTER TABLE `tmp_gejala`
 ADD PRIMARY KEY (`noip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bobot`
--
ALTER TABLE `bobot`
MODIFY `id_bobot` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `hasil`
--
ALTER TABLE `hasil`
MODIFY `id_hasil` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `peternak`
--
ALTER TABLE `peternak`
MODIFY `id_peternak` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `tmp_gejala`
--
ALTER TABLE `tmp_gejala`
MODIFY `noip` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=131388;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
