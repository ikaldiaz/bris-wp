<?php 
include "../koneksi.php";
?>
<html>
<head>
<title>Tampilan Data Penyakit</title>
<script type="text/javascript">
function konfirmasi(id_user){
	var kd_hapus=id_user;
	var url_str;
	url_str="hapus_user.php?id_user="+kd_hapus;
	var r=confirm("Yakin ingin menghapus data..?"+kd_hapus);
	if (r==true){   
		window.location=url_str;
		}else{
			//alert("no");
			}
	}

</script>
</head>
<body>
<h2>Laporan Data Pengguna</h2><hr> <a id="cetak"  style="cursor: pointer;">Cetak</a>
<div id="laporanx">
  
<table width="100%" border="0" cellpadding="2" cellspacing="1" bgcolor="#22B5DD">
   <tr bgcolor="#CCCC99"> 
    <td colspan="8"><div align="center"><strong>Laporan Pengguna </strong></div></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="2" cellspacing="1" bgcolor="#22B5DD" id="tabelpengguna">
  <thead>
  <tr bordercolor="#CCFFFF" bgcolor="#DBEAF5"> 
    <td width="29"><div align="center"><strong>No</strong></div></td>
    <td width="147"><div align="center"><b>Nama</b></div></td>
    <td width="74"><div align="center"><strong>Kelamin</strong></div></td>
    <td width="73" align="center"><div align="center"><strong>Umur</strong></div></td>
    <td width="166" align="center"><div align="center"><strong>Alamat</strong></div></td>
    <td width="235" align="center"><div align="center"><strong>Penyakit Yang diderita </strong></div></td>
    <td width="150" align="center"><strong>Tanggal Diagnosa</strong> </td>
  </tr>
  </thead>
  <tbody>
  <?php 
  #    <td width="96" align="center"><div align="center	"><strong>Pilih</strong></div></td>
	//$sql = "SELECT hasil.id_hasil hasil,penyakit WHERE hasil.kd_penyakit=penyakit.kd_penyakit order by id_hasil";
	$sql = "SELECT hasil.id_hasil, hasil.id_peternak, hasil.kd_penyakit, hasil.tanggal, peternak.id_peternak, peternak.nama, peternak.kelamin, peternak.umur, peternak.alamat, penyakit.kd_penyakit, penyakit.nama_penyakit FROM hasil, peternak, penyakit WHERE hasil.kd_penyakit=penyakit.kd_penyakit";
	$qry = mysql_query($sql, $koneksi)  or die ("SQL Error".mysql_error());
	$no=0;
	while ($data=mysql_fetch_array($qry)) {
	$no++;
  ?>
  <tr bgcolor="#FFFFFF"> 
    <td><?php echo $no; ?></td>
    <td><?php echo $data['nama']; ?></td>
    <td><?php echo $data['kelamin']; ?></td>
    <td><?php echo $data['umur']; ?></td>
    <td><?php echo $data['alamat']; ?></td>
    <td class="name"><?php echo $data['nama_penyakit']; ?> ( <?php echo $data['kd_penyakit']; ?> )</td>
    <td><?php echo $data['tanggal']; ?>&nbsp;|<a title="hapus pengguna" style="cursor:pointer;" onClick="return konfirmasi('<?php echo $data['id_peternak'];?>')"><img src="image/hapus.jpeg" width="16" height="16" ></a></td>
  </tr>
  <?php
  }
  ?>
  </tbody>
</table>
</div>
</body>
</html>
