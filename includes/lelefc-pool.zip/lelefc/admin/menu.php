<ul class="art-hmenu">
		<li>
			<a href="haladmin.php?top=home.php"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=penyakit_solusi.php"><span class="l"></span><span class="r"></span><span class="t">Penyakit & Solusi </span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=gejala.php" ><span class="l"></span><span class="r"></span><span class="t">Gejala</span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=relasi.php"><span class="l"></span><span class="r"></span><span class="t">Relasi</span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=lapgejala.php"><span class="l"></span><span class="r"></span><span class="t">Laporan Gejala</span></a>
		</li>
        <li>
			<a href="haladmin.php?top=lapuser.php"><span class="l"></span><span class="r"></span><span class="t">Laporan User</span></a>
		</li>		
		<li>
			<a href="logout.php"><span class="l"></span><span class="r"></span><span class="t">Logout</span></a>
		</li>	
</ul>