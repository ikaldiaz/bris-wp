<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Sistem Pakar Penyakit Lele Pak Subadi</title>
	<style type="text/css">
	<!--
	.style1 {
		font-family: Georgia, "Times New Roman", Times, serif;
		font-size: 12px;
	}
	.style2 {
		font-family: Georgia, "Times New Roman", Times, serif;
		font-size: 12px;
	}
	-->
	</style>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<h2>Selamat Datang di Administrator</h2>
<table width="100%" height="25" align="center">
</table>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
        <ul>	
		<li>
			<strong><a href="haladmin.php?top=penyakit_solusi.php"><span class="t">Penyakit & Solusi </span></a>
	      </strong></li>	
		<li>
			<strong><a href="haladmin.php?top=gejala.php" ><span class="t">Gejala</span></a>
	      </strong></li>	
		<li>
			<strong><a href="haladmin.php?top=relasi.php"><span class="t">Relasi</span></a>
	      </strong></li>	
		<li>
			<strong><a href="haladmin.php?top=lapgejala.php"><span class="t">Laporan Gejala</span></a>
	      </strong></li>
        <li>
			<strong><a href="haladmin.php?top=lapuser.php"><span class="t">Laporan User</span></a>
	      </strong></li>
</ul>
        </blockquote>
    </div></td>
  </tr>
</table>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="../js/jquery-1.11.3.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../js/bootstrap.min.js"></script>
</body>
</html>
