<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <!--
    Created by Artisteer v3.0.0.38499
    Base template (without user's data) checked by http://validator.w3.org : "This page is valid XHTML 1.0 Transitional"
    -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Informasi</title>
    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->



</head>
<body>
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet container">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-headerobject"></div>
                <div class="art-logo">
                                <h1 class="art-logo-name"><a href="index.php">Diagnosa Penyakit Ikan Lele</a></h1>
                                                 <h2 class="art-logo-text">Sistem Pakar Mendiagnosa Penyakit Ikan Lele<br /> Metode Forward Chaining</h2>
                                               <input type="text" class="fuzzy-search" />
                                </div>
            </div>
            <div class="cleared reset-box"></div><div class="art-nav">
	<div class="art-nav-l"></div>
	<div class="art-nav-r"></div>
<div class="art-nav-outer">
	<ul class="art-hmenu">
		<li>
			<a href="home.php"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
		</li>	
		<li>
			<a href="proses-diagnosa.php?top=pasien_add_fm.php"><span class="l"></span><span class="r"></span><span class="t">Proses Diagnosa</span></a>
		</li>	
		<li>
			<a href="informasi.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Informasi</span></a>
		</li>	
		<li>
			<a href="tentang.php"><span class="l"></span><span class="r"></span><span class="t">Tentang</span></a>
		</li>	
		<li>
			<a href="daftar-penyakit.php"><span class="l"></span><span class="r"></span><span class="t">Daftar Penyakit</span></a>
		</li>	
		<li>
			<a target="_blank" href="admin/index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>
		</li>	
	</ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout">
                <div class="art-content-layout-row">
                    
                    <div class="art-layout-cell art-content col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner art-article">
                                <h2 class="art-postheader">
                <img src="images/postheadericon.png" width="28" height="27" alt="" />Informasi Ikan Lele
                </h2>
                                <div class="art-postcontent">
                                  <div>
                                    <div id="post17977261708825222172">
                                      <div dir="ltr" trbidi="on"> Ikan lele juga sering disebut dengan ikan keli merupakan salah satu   jenis ikan yang hidup di air tawar. Ikan ini memiliki nama latin Clarias   Sp. Lele cukup mudah dikenali karena bentuknya yang berbeda dari ikan   pada umumnya.<br />
                                        <br />
                                        Lele memiliki tubuh yang licin, berbentuk pipih serta memanjang,   binatang air ini juga memiki kumis panjang di bagian kepalanya. Kumis   tersebut mencuat di bagian sekitar daerah mulut lele. Lele tidak   memiliki sisik seperti ikan pada umumnya.<br />
                                        <br />
                                        Memiliki sirip anus serta sirip punggung yang memanjang, yang terkadang   menyatu dengan sirip ekornya. Kepalanya sangat keras dengan mulut yang   cukup lebar, serta mata yang sangat kecil.<br />
                                        <table cellspacing="0" cellpadding="0" align="center">
                                          <tbody>
                                            <tr>
                                              <td><a href="https://2.bp.blogspot.com/-5Jg7N5epCqc/Vw4OG8EA1PI/AAAAAAAAGXA/Gr-sEZCI2UIE1Z9_jMiFB1ryAW2rZZWtgCLcB/s1600/Fakta%2BUnik%2Bdan%2BInformasi%2BMengenai%2BIkan%2BLele.jpg" imageanchor="1"><img src="images/sapi.jpg" width="400" height="268" border="0" /></a></td>
                                            </tr>
                                            <tr>
                                              <td>pixabay</td>
                                            </tr>
                                          </tbody>
                                        </table>
                                        Ikan ini juga memiliki 4 pasang barbels atau disebut dengan sungut perba   yang berfungsi untuk bergerak di dalam air yang gelap. Lele ternyata   juga memiliki alat pernapasan tambahan yakni dari modifikasi busur   insang lele tersebut.<br />
                                        <br />
                                        Ikan lele juga memiliki patil, yang merupakan duri pada sirip dadanya.   Patil tersebut merupakan duri tulang tajam. Beberapa orang percaya bahwa   patil tersebut beracun. Racun tersebut dapat menyebabkan orang menjadi   panas tinggi.<br />
                                        <br />
                                        Habitat atau tempat tinggal ikan lele pada umumnya di air yang   menggenang serta tenang seperti aliran sungai yang tenang, rawa-rawa,   genangan sawah serta waduk. Namun ternyata ikan ini juga dapat hidup   pada air yang sudah tercemar.<br />
                                        <br />
                                        Air tercemar tersebut misalnya selokan, got-got, air dari limbah   pembuangan kotoran. Sehingga belakangan ini beredar kabar bahwa lele   berbahaya untuk di makan karena mengandung zat yang memicu pertumbuhan   sel kanker.<br />
                                      </div>
                                    </div>
                                    <div>
                                      <center>
                                      <img src="images/sapishorthornjantan.jpg" width="307" />
                                      </center>
                                    </div>
                                    <div id="post27977261708825222172"> 
                                      <p>Benarkah kabar tersebut? Sampai saat ini belum ada penelitian yang   menyebutkan jika memakan ikan lele dapat memicu kanker. Karena hal   tersebut tergantung perawatan ikan tersebut. Jika dirawat pada air yang   bersih dan diberikan makan yang baik maka tentu aman memakan ikan ini.<br />
                                      <br />
                                      <strong>Berikut beberapa fakta unik mengenai Ikan Lele :</strong><br />
                                      <br />
                                      <strong>1.</strong> Merupakan ikan yang memiliki sifat nokturnal, sehingga dia   akan aktif bergerak di malam hari untuk mencari makan dan pada siang   hari lele akan lebih diam dengan bersembunyi di tempat-tempat yang   gelap.<br />
                                      <br />
                                      <strong>2</strong>. Selain dapat dikonsumsi sebagai makanan, di Iran, Irak serta   beberapa daerah timur tengah lain, lele dimanfaatkan menjadi salah satu   jenis ikan hias.<br />
                                      <br />
                                      <strong>3.</strong> Ikan ini mengandung lemak serta protein yang baik untuk tubuh,   khususnya bagi ibu hamil. Karena daging lele baik bagi pertumbuhan   janin bayi dalam kandungan.<br />
                                      <br />
                                      <strong>4.</strong> Ikan lele ternyata memiliki hari nasional yakni pada tanggal   25 Juni. Hal ini karena pada tanggal tersebut di tahun 1987, merupakan   hari untuk memperingati kebangkitan peternak lele di Amerika Serikat.   Hari Nasional Ikan Lele itu ditetapkan sendiri oleh Presiden AS kala itu   yaitu Ronald Reagan.<br />
                                      <br />
                                      <strong>5.</strong> Terkadang <strong><a href="http://www.kopi-ireng.com/2013/03/tips-dan-cara-budidaya-ikan-lele-dumbo.html" target="_blank">ikan lele</a></strong> juga ditaruh di sawah untuk memakan hama-hama yang ada di sawah. Lele   juga sering pula di taruh pada kolam atau tempat air tergenang untuk   mengurangi tumbuhnya jentik-jentik nyamuk.<br />
                                      <br />
                                      <strong>6.</strong> Karena ikan ini memang dapat hidup di berbagai macam perairan,   maka Anda dapat menemuinya di hampir semua benua. Namun uniknya di   antara semua benua, lele tidak dapat Anda temukan di Alaska dan   Antartika.<br />
                                      <br />
                                      <strong>7. </strong>Selain manusia yang di mumikan, ternyata ikan lele juga di   jadikan mumi. Mumi ikan tersebut berada di Rosicrucian Egyptian Museum   tepatnya di San Jose, California. Mumi tersebut menjadi persembahan   Kerajaan Tengah Mesir yang berasal dari sungai Nil.<br />
                                      <br />
                                      <strong>8.</strong> Mitologi di Negara Jepang, menceritakan mengenai si Namazu   yang merupakan lele raksasa. Lele tersebut menyebabkan bencana gempa   bumi. Si lele raksasa tersebut dikatakan tinggal di lumpur, lumpur   tersebut terletak di bagian bawah daerah kepulauan Jepang serta dijaga   oleh dewa Kashima, dewa tersebut menahan lele raksasa tersebut dengan   batu besar. Lele Namazu tersebut kemudian disembah sabagai dewa   rektifikasi dunia.<br />
                                      <br />
                                      <strong>9.</strong> Ikan lele menempati urutan ke-5 yang menjadi ikan terpopuler   di Amerika Serikat. Pasokan ikan ini selalu tersedia selama sepanjang   tahun.<br />
                                      <br />
                                      <strong>10.</strong> Ikan ini ternyata dapat bertahan hidup di darat cukup lama.   Ikan ini juga dapat berpindah dari genangan air yang satu ke genangan   air lainnya melalui jalan darat. </p>
                                      <h2 itemprop="name"> <a href="http://www.tanijogonegoro.com/2013/06/ikan-lele.html" title="MENGENAL IKAN LELE">MENGENAL IKAN LELE</a></h2>
                                      <div>
                                        <div></div>
                                      </div>
                                      <div id="post-body-2483938621705664904"> 
                                        <p>Kebanyakan masyarakat Indonesia sudah tidak asing lagi dengan <strong>ikan lele</strong>.   Ikan yang menjadi komoditas agribisnis yang memiliki prospek bisnis   cerah ini banyak dibudidayakan oleh masyarakat, baik di kolam tanah,   kolam tembok, atau kolam terpal. Saat ini upaya membudidayakan ikan lele   di kolam terpal sangat marak dilakukan oleh masyarakat.</p>
                                        <p><table cellspacing="0" cellpadding="0" align="center">
                                          <tbody>
                                            <tr>
                                              <td><a  imageanchor="1"><img src="images/sapibrangusjantan.jpg" width="400" height="268" border="0" /></a></td>
                                            </tr>
                                            <tr>
                                              <td>pixabay</td>
                                            </tr>
                                          </tbody>
                                        </table>
                                          Dari segi cita rasa, ikan lele memiliki tekstur daging yang lezat dan   disukai konsumen. Kegemaran masyarakat terhadap komoditas perikanan yang   satu ini bisa dilihat dari begitu banyaknya warung makan yang   menyediakan menu ikan lele selalu ramai dikunjungi orang. Selain cita   rasanya yang enak, daging ikan lele juga tidak dipenuhi tulang-tulang   kecil seperti ikan-ikan lain, misalnya ikan mas. Hal ini memudahkan   orang untuk mengkonsumsi daging ikan lele tersebut tanpa harus menelisik   tulang-tulang kecil yang menyelip dalam daging.<br />
                                          <br />
                                        </p>
                                        <h2>Morfologi Ikan Lele</h2>
                                        Ikan lele merupakan jenis ikan air tawar   yang memiliki warna tubuh kehitaman atau kecokelatan. Tubuh ikan lele   berkulit licin karena diselimuti lendir, dan tidak memiliki sisik   seperti ikan-ikan lain. Hal yang menarik dari tubuh ikan lele ini adalah   apabila terkena sinar matahari, maka warna tubuh ikan lele akan berubah   menjadi pucat. Warna tubuh tersebut juga akan berubah jika ikan lele   terkejut menjadi loreng hitam putih seperti mozaik. Ikan lele memiliki   mulut yang berukuran kurang lebih ¼ dari panjang tubuhnya. Ikan lele   juga dijuluki catfish karena memiliki kumis disekitar mulut yang   berjumlah delapan buah sehingga menyerupai kucing. Kumis ikan lele   tersebut berfungsi sebagai alat peraba saat mencari makanan atau sedang   bergerak.<br />
  <br />
                                        <table cellspacing="0" cellpadding="0" align="center">
                                          <tbody>
                                            <tr>
                                              <td><a href="https://2.bp.blogspot.com/-5Jg7N5epCqc/Vw4OG8EA1PI/AAAAAAAAGXA/Gr-sEZCI2UIE1Z9_jMiFB1ryAW2rZZWtgCLcB/s1600/Fakta%2BUnik%2Bdan%2BInformasi%2BMengenai%2BIkan%2BLele.jpg" imageanchor="1"><img src="images/sapiherefordjantan.jpg" width="400" height="268" border="0" /></a></td>
                                            </tr>
                                            <tr>
                                              <td>pixabay</td>
                                            </tr>
                                          </tbody>
                                        </table>Seperti kebanyakan ikan-ikan air tawar lain, ikan lele menggunakan sirip   untuk bergerak atau berenang. Sirip ikan lele terdiri dari dua buah   sirip dada yang berpasangan, dua buah sirip perut yang berpasangan, satu   buah sirip dubur, satu buah sirip ekor, dan satu buah sirip punggung.   Sirip dada pada ikan lele dilengkapi dengan sirip keras dan runcing yang   berfungsi sebagai senjata dan alat gerak. Sirip keras tersebut sering   dikenal dengan istilah patil. Sirip perut terletak di bagian bawah   tubuhnya. Sementara itu, sirip dubur terletak dibelakang sirip perut   yang membentang hingga pangkal ekor. Sirip ekor ikan lele berbentuk   busur agak membulat. Dan sirip punggung pada ikan lele berada di atas   tubuhnya yang mementang hingga ke pangkal ekor bagian atas. <br />
  <br />
  <h2>Klasifikasi ikan lele</h2>
  <div><br />
    <br />
    <br />
  </div>
                                        Ikan lele termasuk ke dalam ordo: Ostariophysi, subordo: Silaroidae, famili: Clariidae, genus Clarias, dan spesies <em>Clarias sp</em>.<br />
  <br />
  <h3>Syarat Hidup Ikan Lele</h3>
                                        Ikan lele memiliki organ arborescent atau   insang tambahan yang dikenal pula dengan sebutan labyrinth. Organ   tersebut berfungsi sebagai alat untuk bertahan hidup saat ikan lele   berada di dalam lumpur atau di dalam perairan yang sedikit mengandung   oksigen.<br />
  <br />
                                        Kelebihan ikan lele tersebut membuat ikan ini menjadi pilihan budidaya   oleh para petani pembudidaya ikan lele. Kelebihan membudidayakan ikan   lele ini adalah ikan lele mampu bertahan hidup dengan pertumbuhan dan   perkembangan yang optimal meskipun dibudidayakan di dalam kolam yang   memiliki kualitas air kurang baik. Hal ini sangat berseberangan dengan   ikan-ikan yang biasa dibudidayakan lainnya yang memerlukan kualitas yang   yang baik. Oleh karena itu, <a href="http://www.tanijogonegoro.com/2013/02/budidaya-lele.html" title="Budidaya Lele">budidaya lele</a> ini dapat dilakukan di comberan atau kolam-kolam dengan sumber air yang   terbatas, seperti kolam terpal yang dibuat di pekarangan rumah. Akan   tetapi, dalam membudidayakan ikan lele ini, meskipun daya hidupnya   (survival rate) lebih tinggi dibanding ikan-ikan lain, tetap harus   dipenuhi paling tidak kriteria standar minimal untuk lingkungan hidup   ikan lele.<br />
  <br />
                                        Untuk menunjang keberhasilan budidaya dan mengoptimalkan pertumbuhan dan   perkembangan ikan lele, para ahli perikanan penetapkan kriteria atau   standar minimal untuk kualitas air pada kolam budidaya ikan lele, baik   secara kimia maupun fisika, yang harus dipenuhi untuk membudidayakan   ikan lele. Beberapa syarat dan kualitas air yang dibutuhkan untuk   menopang kehidupan ikan lele antara lain:<br />
  <ol>
    <li>Suhu optimal untuk pemeliharaan ikan lele berkisar antara 20-30° C. </li>
    <li>Suhu optimal untuk kehidupan ikan lele agar pertumbuhan dan perkembangannya optimal adalah 27° C. </li>
    <li>Kandungan oksigen terlarut di dalam air minimum sebanyak 3 ppm (miligram per liter). </li>
    <li>Derajat keasaman (pH) air untuk kehidupan ikan lele dapat mencapai pertumbuhan dan perkembangan yang optimal adalah 6,5-8. </li>
    <li>Kandungan karbondioksida (CO₂) dalam air harus di bawah 15 ppm; NH,   sebesar 0,05 ppm; NO, sebesar 0,25 ppm; dan NO, sebesar 250 ppm. </li>
  </ol>
  <br />
  <h3>Kebiasaan Hidup Ikan Lele</h3>
                                        Di habitat aslinya yaitu di perairan   bebas, ikan ikan lele memiliki kebiasaan untuk memijah pada awal musim   penghujan. Pada musim penghujan, ikan lele mengalami rangsangan untuk   memijah karena terjadinya peningkatan kedalaman air. Kebiasaan tersebut   juga bisa dilihat pada usaha pembenihan ikan lele yang dilakukan secara   tradisional. Pada kegiatan usaha <a href="http://www.tanijogonegoro.com/2013/06/budidaya-lele.html" title="Budidaya Lele Tradisional">pembenihan tradisional</a> proses pemijahan ikan lele tidak berbeda jauh dengan kebiasaan   alaminya. Hal ini tentu sangat berbedan dengan pemijahan ikan lele   terutama pada budidaya ikan lele <a href="http://www.tanijogonegoro.com/2013/06/lele-budidaya.html" title="Budidaya Lele Semiintensif">pembenihan semiintensif</a> dan intensif. Pada kedua sistem pembenihan tersebut, ikan lele diberi   rangsangan untuk memijah, yaitu dengan memberikan zat tertentu melalui   suntikan.<br />
<table cellspacing="0" cellpadding="0" align="center">
                                          <tbody>
                                            <tr>
                                              <td><a href="https://2.bp.blogspot.com/-5Jg7N5epCqc/Vw4OG8EA1PI/AAAAAAAAGXA/Gr-sEZCI2UIE1Z9_jMiFB1ryAW2rZZWtgCLcB/s1600/Fakta%2BUnik%2Bdan%2BInformasi%2BMengenai%2BIkan%2BLele.jpg" imageanchor="1"><img src="images/santagertrudisjantan.jpg" width="400" height="268" border="0" /></a></td>
                                            </tr>
                                            <tr>
                                              <td>pixabay</td>
                                            </tr>
                                          </tbody>
                                        </table>
                                        Kebiasaan alami ikan lele untuk memijah tersebut dalam kegiatan <a href="http://www.tanijogonegoro.com/2013/02/budidaya-lele.html" title="Budidaya Lele">budidaya ikan lele</a> bisa disiasati dengan memanipulasi lingkungan di kolam budidaya untuk merangsang ikan lele memijah di luar musim hujan.<br />
 <table cellspacing="0" cellpadding="0" align="center">
                                          <tbody>
                                            <tr>
                                              <td><a href="https://2.bp.blogspot.com/-5Jg7N5epCqc/Vw4OG8EA1PI/AAAAAAAAGXA/Gr-sEZCI2UIE1Z9_jMiFB1ryAW2rZZWtgCLcB/s1600/Fakta%2BUnik%2Bdan%2BInformasi%2BMengenai%2BIkan%2BLele.jpg" imageanchor="1"><img src="images/sapilimousin.jpg" width="400" height="268" border="0" /></a></td>
                                            </tr>
                                            <tr>
                                              <td>pixabay</td>
                                            </tr>
                                          </tbody>
                                        </table>
                                        Cara pemijahan ikan lele secara alami di alam dapat diilustrasikan sebagai berikut.<br />
  <ol>
    <li>Ketika musim penghujan datang, ikan lele yang siap memijah   (matang kelamin atau matang gonad) akan mencari lokasi sesuai dengan   keinginannya.</li>
    <li>Gerombolan ikan lele jantan dan betina yang telah matang kelamin   tersebut berpijah. Ikan lele betina meletakkan telur-telurnya di bagian   pinggiran perairan.</li>
    <li>Pada saat bersamaan, ikan lele jantan menyemprotkan spermanya pada   telur-telur tersebut. Telur-telur yang telah dibuahi akan menempel pada   batu-batuan atau tanaman air yang ada di pinggiran perairan.</li>
    <li>Beberapa hari kemudian (tergantung pada suhu perairan) telur-telur ikan lele tersebut akan merietas dengan sendirinya.</li>
  </ol>
                                      Produksi yang dihasilkan dari pemijahan secara alami ini jumlahnya   sangat sedikit. Hal ini disebabkan benih-benih yang baru menetas   sebagian besar mengalami kematian, karena tidak tahan dengan kondisi   lingkungan perairan yang sangat ekstrem. Sementara itu, tidak sedikit   benih yang masih hidup dimangsa oleh predator-predator yang ada di   perairan tersebut. Bisa juga terjadi, predator atau pemangsa sudah   memangsa telur yang dibuahi ketika telur tersebut belum sempat menetas.</div>
                                      <p>&nbsp;</p>
                                    </div>
                                    <p>&nbsp;</p><div>
                                    </div>
                                  </div>
                                  <p><br /></p>


                </div>
                <div class="cleared"></div>
                </div>

		<div class="cleared"></div>
    </div>
</div>

                      <div class="cleared"></div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-t"></div>
                <div class="art-footer-body">
                            <div class="art-footer-text">
                                
<p>Sistem Pakar Mendeteksi Penyakit Ikan Lele</p>
<p>Copyright © 2021. All Rights Reserved. Programmer by  Herlina Intan </p>


                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
    <p class="art-page-footer">&nbsp;</p>
</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-1.11.3.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>

    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
</body>
</html>
