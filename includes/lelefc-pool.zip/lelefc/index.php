<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <!--
    Created by Artisteer v3.0.0.38499
    Base template (without user's data) checked by http://validator.w3.org : "This page is valid XHTML 1.0 Transitional"
    -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Selamat Datang</title>
    <meta name="description" content="Description" />
    <meta name="keywords" content="Keywords" />


    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->



</head>
<body>
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet container">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body row">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-headerobject"></div>
                <div class="art-logo">
                                 <h1 class="art-logo-name"><a href="index.php">Diagnosa Penyakit Ikan Lele</a></h1>
                                                 <h2 class="art-logo-text">Sistem Pakar Mendiagnosa Penyakit Ikan Lele<br /> Metode Forward Chaining (FC)</h2>
                                                 <input type="text" class="fuzzy-search" />
                                </div>
            </div>
            <div class="cleared reset-box"></div><div class="art-nav">
	<div class="art-nav-l"></div>
	<div class="art-nav-r"></div>
<div class="art-nav-outer">
	<ul class="art-hmenu">
		<li>
			<a href="home.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
		</li>	
		<li>
			<a href="proses-diagnosa.php?top=pasien_add_fm.php"><span class="l"></span><span class="r"></span><span class="t">Proses Diagnosa</span></a>
		</li>	
		<li>
			<a href="informasi.php"><span class="l"></span><span class="r"></span><span class="t">Informasi</span></a>
		</li>	
		<li>
			<a href="tentang.php"><span class="l"></span><span class="r"></span><span class="t">Tentang</span></a>
		</li>	
		<li>
			<a href="daftar-penyakit.php"><span class="l"></span><span class="r"></span><span class="t">Daftar Penyakit</span></a>
		</li>	
		<li>
			<a target="_blank" href="admin/index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>
		</li>	
	</ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout row">
    <div class="art-content-layout-row">
        <div class="art-layout-cell art-content col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="art-post">
                <div class="art-post-body">
                    <div class="art-post-inner art-article">
                        <h2 class="art-postheader">
                            <img src="images/postheadericon.png" width="28" height="27" alt="" />Selamat Datang
                        </h2>
                        <div class="art-postcontent">

                            <p><marquee scrolldelay="20">
                              Welcome to website sistem pakar penyakit ikan lele
                          </marquee></p>
                          <p><img width="250" src="images/sapi-jibiphoto.jpg" alt="an image" style="float:left;" />Sistem pakar diagnosa penyakit pada ikan lele ini merupakan sebuah sistem yang dapat membantu para peternak budidaya lele dalam mendiagnosa penyakit dan gejala pada ikan lele. sistem ini menggunakan basis pengetahuan yang didapatkan dari beberapa pakar dari dinas perikanan dan pertanian.</p>
                          <p>Sistem pakar ini menggunakan metode Forward Chaining yg berbasis penalaran kasus yang dapat memberikan output berupa penyakit apa saja yang diderita oleh lele berdasarkan gejala yang diinput.</p>
                          <p>Penanggulangan dari serangan hama bisa dilakukan dengan berbagai hal seperti memagari pinggiran kolam, menyaring jalan masuk dan keluar air, sampai menutup kolam dengan paranet. Apabila kita beternak lele secara intensif, biasanya gangguan hama jarang terjadi karena kolam relatif terawasi terus menerus. <img width="320" src="images/sapi.jpg" alt="an image" style="float:right;" />Dalam beternak lele, hama merupakan gangguan yang bersumber dari organisme besar baik yang sifatnya predator, penggangu dan pesaing. Hama ikan lele yang bersifat predator adalah musang, linsang, dan ular. Di daerah perkotaan kucing pun kadangkala menjadi hama yang perlu di waspadai. Selain itu, ada juga katak yang merupakan predator bagi benih lele yang masih kecil.</p>
                          <p>Serangan hama dan penyakit ikan lele bisa dihindari dengan memperbaiki manajemen budidaya. Namun meskipun begitu, tetap saja masih ada faktor eksternal yang tidak bisa dielakkan 100 persen. Banyak hal-hal tidak terduga yang bisa terjadi ketika kita membudidayakan ikan lele.</p>


                      </div>
                      <div class="cleared"></div>
                  </div>

                  <div class="cleared"></div>
              </div>
          </div>

          <div class="cleared"></div>
      </div>
  </div>
</div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-t"></div>
                <div class="art-footer-body">
                            <div class="art-footer-text">
                                
<p>Sistem Pakar Mendeteksi Penyakit Ikan Lele</p>
<p>Copyright © 2021. All Rights Reserved. Programmer by .Herlina Intan MIA 17.</p>


                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
    <p class="art-page-footer">&nbsp;</p>
</div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-1.11.3.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>



    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
</body>
</html>
