<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <!--
    Created by Artisteer v3.0.0.38499
    Base template (without user's data) checked by http://validator.w3.org : "This page is valid XHTML 1.0 Transitional"
    -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Informasi Penyakit</title>


    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="art-sheet container">
        <div class="art-sheet-tl"></div>
        <div class="art-sheet-tr"></div>
        <div class="art-sheet-bl"></div>
        <div class="art-sheet-br"></div>
        <div class="art-sheet-tc"></div>
        <div class="art-sheet-bc"></div>
        <div class="art-sheet-cl"></div>
        <div class="art-sheet-cr"></div>
        <div class="art-sheet-cc"></div>
        <div class="art-sheet-body">
            <div class="art-header">
                <div class="art-header-clip">
                <div class="art-header-center">
                    <div class="art-header-jpeg"></div>
                </div>
                </div>
                <div class="art-headerobject"></div>
                <div class="art-logo">
                                 <h1 class="art-logo-name"><a href="./index.html">Diagnosa Penyakit Sapi</a></h1>
<h2 class="art-logo-text">Sistem Pakar Mendiagnosa Penyakit Ikan Lele<br /> Metode Forward Chaining</h2>
 <input type="text" class="fuzzy-search" />
                                </div>
            </div>
            <div class="cleared reset-box"></div><div class="art-nav">
	<div class="art-nav-l"></div>
	<div class="art-nav-r"></div>
<div class="art-nav-outer">
	<ul class="art-hmenu">
		<li>
			<a href="./home.php"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
		</li>	
		<li>
			<a href="proses-diagnosa.php?top=pasien_add_fm.php"><span class="l"></span><span class="r"></span><span class="t">Proses Diagnosa</span></a>
		</li>	
		<li>
			<a href="./informasi.php"><span class="l"></span><span class="r"></span><span class="t">Informasi</span></a>
		</li>	
		<li>
			<a href="./tentang.php"><span class="l"></span><span class="r"></span><span class="t">Tentang</span></a>
		</li>	
		<li>
			<a href="daftar-penyakit.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Daftar Penyakit</span></a>
		</li>	
		<li>
			<a target="_blank" href="admin/index.php"><span class="l"></span><span class="r"></span><span class="t">Login</span></a>
		</li>	
	</ul>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-content-layout">
                <div class="art-content-layout-row">
                    
                    <div class="art-layout-cell art-content col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader"><img src="images/postheadericon.png" width="28" height="27" alt="" />Informasi Penyakit Ikan Lele</h2>
<div class="art-postcontent">

<p><br /></p>
<table width="95%" border="0" align="center" cellpadding="2" cellspacing="1" bgcolor="#22B5DD">
  <tr bgcolor="#CCCC99">
    <td colspan="3"><b><center>
      Daftar Jenis-jenis Penyakit Pada Ikan Lele
    </center></b></td>
  </tr>
  <tr bgcolor="#DBEAF5"> 
    <td width="244" bgcolor="#CCCC99">&nbsp;</td>
  </tr>
  <?php
  	include "koneksi.php"; 
	$sql = "SELECT * FROM penyakit ORDER BY kd_penyakit";
	$qry = mysql_query($sql, $koneksi) or die ("SQL Error".mysql_error());
	$no=0;
	while ($data=mysql_fetch_array($qry)) {
	$no++;
  ?>
  <tr bgcolor="#FFFFFF"> 
    <td><div align="left">
      <ul type="square" compact="compact"><div align="left"><?php echo "<h3><em>$data[nama_penyakit]</em></h3>"; ?></div>
        
        <li><label>Definisi Penyakit :</label><p><?php echo "$data[definisi]";?></p></li>
        <li><label>Solusi :</label><p><?php echo "$data[solusi]";?></p>
  </li>
        </ul>
      
    </td>
  </tr>
  <?php
  }
  ?>
</table>

                </div>
                <div class="cleared"></div>
                </div>

		<div class="cleared"></div>
    </div>
</div>

                      <div class="cleared"></div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-t"></div>
                <div class="art-footer-body">
                            <div class="art-footer-text">
                                
<p>Sistem Pakar Mendeteksi Penyakit Ikan Lele</p>
<p>Copyright © 2021. All Rights Reserved. Programmer by Herlina Intan</p>


                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
    <p class="art-page-footer">&nbsp;</p>
</div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-1.11.3.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>

    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
</body>
</html>
